# Canonical Source Index

JSONL is authoritative where embedded. CSV is the spreadsheet-safe derivative. Per-day manifests or authority references record collection and validation metadata.

| Date | Wrapper | Canonical | Ancestry | Both | Ancestry-only | Window-only | Status |
|---|---|---:|---:|---:|---:|---:|---|
| 2026-10-28 | 0.4.1 | 170 | 127 | 127 | 0 | 43 | PASS / embedded |
| 2026-10-29 | 0.4.1 | 121 | 65 | 65 | 0 | 56 | PASS / embedded |
| 2026-11-02 | 0.5.2 | 261 | 227 | 227 | 0 | 34 | PASS / exact final bytes in loading dock |
| 2026-11-03 | 0.5.2 | 230 | 195 | 195 | 0 | 35 | PASS / exact JSONL + manifest embedded; review CSV derived |

## Important

The creator/date canonical layers elsewhere in this packet are the broad normalized archival corpus reconstructed from surviving raw pulls. These wrapper day bundles are higher-confidence structural reconstructions for the listed Grant Smith Ellis dates and should control for those dates when the two layers differ.

**November 3 availability:** The exact v0.5.2 JSONL and its original manifest are embedded and SHA-256 matched. The original wrapper-generated CSV and reconciliation/raw/parent files listed by the day manifest were not supplied in this handoff. The included `REVIEW_DERIVATIVE_FROM_JSONL.csv` is a newly generated convenience file, not the manifested original CSV.
