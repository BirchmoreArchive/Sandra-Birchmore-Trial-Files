# Sandra Birchmore Trial — X Source Packet (Rebuilt)

This packet is a preservation-oriented source dataset assembled from surviving X/Twitter extraction pulls related to Sandra Birchmore / Matthew Farwell trial reporting and supplemental courtroom reporters.

It is intended for archivists, researchers, journalists, and future maintainers who need the underlying records without repeating the original extraction experiments.

## Fast start

- **Use `canonical_raw/`** when you need the selected extracted record without normalization.
- **Use `canonical_normalized/`** for easier text work where reversible character-encoding repair was applied.
- **Use `canonical_sources/GrantSmithEllis/`** for structurally validated wrapper reconstructions on dates where they exist. Those higher-confidence day bundles control for those dates.
- **Use `provenance/tweet_provenance.jsonl`** to trace any canonical tweet back to every surviving extraction occurrence.
- **Use `media/media_manifest.json`** to identify media references and recovery priority.
- **Use `source_bundles/`** when you need the preserved source pulls themselves.

## Current reconstructed corpus

- 87 JSONL source instances were processed from selected surviving bundles and unique loose pulls.
- 14,609 tweet-record occurrences resolve to **5,281 unique tweet IDs**.
- 350 creator/date canonical files span 165 top-level creators.
- 991 selected tweet records received a reversible mojibake repair in the normalized derivative.
- 4 extractor/error records are preserved separately rather than silently dropped.
- 801 unique media objects are indexed for later recovery.

These counts describe the **rebuild corpus**, not a claim that X itself returned every historical post.

## Canonical layers

### `canonical_raw/`

For each unique status ID, the rebuild selects the richest surviving record variant, using record completeness/metadata richness rather than simply choosing the newest filename. The selected original JSON line is preserved without semantic rewriting and filed by the tweet's actual Eastern Time date and top-level creator.

### `canonical_normalized/`

A derivative of `canonical_raw`. It performs only reversible CP437→UTF-8 repair when that conversion succeeds and reduces characteristic corruption markers such as `ΓÇ` / `≡ƒ` / `┬`. No substantive text rewriting is performed.

The raw layer remains the authority for what the extractor returned.

## Provenance

`provenance/tweet_provenance.jsonl` records, for each tweet ID:

- the selected source occurrence;
- selected line number and record hash;
- every surviving source occurrence;
- record-level hashes and byte lengths;
- the number of distinct record variants.

This is why duplicate pulls were not simply discarded before canonicalization: the same tweet can survive with richer metadata or media fields in one extraction than another.

`provenance/source_inventory.csv` describes each source instance processed in the rebuild.

## Historical X search limitation

Historical X SearchTimeline proved unreliable as a completeness mechanism. Repeating the same query can return a stable but incomplete subset. A saturated query therefore means only that the query stopped changing; it does **not** prove that the day is complete.

Where wrapper reconstructions exist, parent/reply ancestry is used as the stronger structural invariant and the historical time-window query is reconciled against it.

Wrapper buckets mean:

- `both` — present in both ancestry and the time-window query;
- `ancestry_only` — structurally recovered from the selected thread but absent from search;
- `window_only` — returned by search but not part of the selected ancestry.

The complete wrapper canonical universe is the union of those buckets.

## Source fidelity

These files are source material, **not official court transcripts**. Grant Smith Ellis and the supplemental creators are contemporaneous reporters/commentators. Transcript-like products in the public Sandra Birchmore Archive are archive-created derivatives and must remain distinguishable from these sources.

Do not silently:

- convert an attorney's question into witness testimony;
- infer a missing answer from the next question;
- convert commentary into a judicial finding;
- harmonize conflicting source records;
- fill gaps by inference.

## Media

`media/media_manifest.json` indexes surviving media references without pretending that the media files themselves have all been recovered.

Priority:

- **A** — media directly attached to a top-level non-retweet source record;
- **B** — top-level media attached to a retweet;
- **C** — media nested inside quoted/retweeted records.

Recovery status currently defaults to `not_attempted` unless later updated.

## Original source bundles

`source_bundles/original_json/` contains the selected original JSON source collections plus unique loose pulls needed to reproduce the canonical corpus. Exact duplicate collections and no-result experimental bundles are intentionally not duplicated in the distributable packet; their relationship is documented in provenance.

`source_bundles/original_images/` preserves the Rex note-image ZIPs as original image sets.

## November 2, 2026

The authoritative Day 16 wrapper run is v0.5.2 with **261 canonical records = 227 `both` + 34 `window_only`**, 100% ancestry coverage. Its exact large JSONL/CSV remain in the private loading dock and are identified by SHA-256 in `canonical_sources/GrantSmithEllis/2026-11-02/AUTHORITATIVE_REMOTE_REFERENCE.json`.

The superseded local 257-record v0.5.0 pair is deliberately **not** substituted for the final files.

## Security

Authentication material is never archival source data. Do not commit or distribute live X auth tokens, cookies, `ct0` values, session credentials, or screenshots containing them.

## Bottom line

**Raw source stays traceable.  
Canonical selection is reproducible.  
Normalization is a labeled derivative.  
Wrapper reconstructions control where available.  
Known gaps remain gaps.**

The point of this packet is that the next archivist should not have to repeat weeks of extraction experiments merely to get back to the surviving source universe.

## November 3, 2026 incremental intake

The November 3 v0.5.2 canonical JSONL (230 statuses) and original manifest are embedded under `canonical_sources/GrantSmithEllis/2026-11-03/`. The original canonical CSV and listed raw provenance components were not part of the supplied handoff. The included review CSV is explicitly labeled a derivative. The pre-existing 5,281-status broad corpus remains a historical snapshot: the incremental day's 230 records were not silently merged into its original source-selection and dedup/provenance layers. See the day-level `INTAKE_NOTES.md`.
