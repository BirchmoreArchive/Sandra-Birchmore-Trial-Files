# Supplemental-source normalization notes

- `SupplementSources.zip` and `SupplementSources (2)(1).zip` are exact duplicate collections at the member-file level; retain one.
- `kristina_rex_farwell_trial` is a strict tweet-ID subset of `kristina_rex_recent`; the broad recent pull can supply the same Oct. 9–27 Rex records, while the narrower filename is useful only as extraction-history provenance.
- The older `since:YYYY-MM-DD until:YYYY-MM-DD` pulls commonly spill into the following Eastern date. Canonical files therefore use each tweet's actual `created_at` timestamp in America/New_York rather than trusting the filename/query label.
- `amelia22(1).zip` contains four no-result experimental searches plus the same 20 tweet IDs preserved in the consolidated Oct. 22 package; it does not need to be public archival material.
- Breslin is the exception where two imperfect pulls genuinely complement each other: the broad recent pull was rate-limited, while the `Farwell` search contains older relevant records absent from it. Canonicalization merges by tweet ID rather than choosing one file.
