# Exact duplicate source-file groups

Only groups with more than one byte-identical JSONL source instance are listed.

## Group 1

SHA-256 `2554f27ef4da8318363108ec654fb41be159ba64e898c857f1ac3d00ae05a780`

- `Grant_Oct14.1_Author_Timebound.jsonl`
- `Grant_Oct14_Author_Timebound(1).jsonl`

## Group 2

SHA-256 `6ee2fc6a5756c8a16bc55c8936ca805cd4ec7b99bb6e4982142f5bd2b97f61fe`

- `Raw files for upload.zip::grant_oct21_interim1_thread.jsonl`
- `Raw files for upload.zip::grant_oct21_lunch_thread.jsonl`

## Group 3

SHA-256 `76eafe2daa314912926627022907def4d67d39e324c4d1ed7feeb1c44f9afc6e`

- `Raw files for upload.zip::grant_today_afternoon_thread.jsonl`
- `Raw files for upload.zip::grant_today_final_thread.jsonl`
- `Raw files for upload.zip::grant_today_interim_thread.jsonl`

## Group 4

SHA-256 `95629a419654503e9a6e87d3b1d0c2e8147abcf0f08af99cab89f568a5b78afa`

- `grant_today_FINAL_thread.jsonl`
- `grant_today_afternoon_thread(1).jsonl`

