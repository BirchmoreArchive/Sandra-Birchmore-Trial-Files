# Source-media ZIP notes

- `rex22(1).zip` — 10 JPG pages, visibly labeled **10/22/26 morning session** on page 1; preserve as an original note-image set rather than merging with JSONL.
- `RexNotes(1).zip` — 8 JPG pages; the set visibly crosses the late-defense/closing transition and includes a page labeled **10/30/26 FULL DAY**. Treat as a mixed late-trial note-image package pending final page-level date naming.

These media ZIPs are not duplicates of one another.
