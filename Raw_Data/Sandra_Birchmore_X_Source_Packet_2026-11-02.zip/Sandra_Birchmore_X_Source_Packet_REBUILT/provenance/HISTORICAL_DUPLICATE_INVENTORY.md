# Exact duplicate groups

33 groups are byte-for-byte duplicates. Keeping one copy per group loses nothing.

## Group 1
- `Raw files for upload.zip::ameliarstern1_oct29.jsonl`
- `ameliarstern1_oct29(1).jsonl`

## Group 2
- `Raw files for upload.zip::boozeybeauty_oct29.jsonl`
- `boozeybeauty_oct29(1).jsonl`

## Group 3
- `Raw files for upload.zip::grant_oct21_interim1_thread.jsonl`
- `Raw files for upload.zip::grant_oct21_lunch_thread.jsonl`

## Group 4
- `Raw files for upload.zip::grant_oct26_full_day.jsonl`
- `grant_oct26_full_day.jsonl`

## Group 5
- `Raw files for upload.zip::grant_oct26_morning_timebound.jsonl`
- `grant_oct26_morning_timebound.jsonl`

## Group 6
- `Raw files for upload.zip::grant_oct27_full_day.jsonl`
- `grant_oct27_full_day(1).jsonl`

## Group 7
- `Raw files for upload.zip::grant_oct27_morning_timebound.jsonl`
- `grant_oct27_morning_timebound.jsonl`

## Group 8
- `Raw files for upload.zip::grant_oct28_full_day.jsonl`
- `grant_oct28_full_day(1).jsonl`

## Group 9
- `Raw files for upload.zip::grant_oct29_full_day.jsonl`
- `grant_oct29_full_day(1).jsonl`

## Group 10
- `Raw files for upload.zip::grant_today_afternoon_thread.jsonl`
- `Raw files for upload.zip::grant_today_final_thread.jsonl`
- `Raw files for upload.zip::grant_today_interim_thread.jsonl`

## Group 11
- `Raw files for upload.zip::kristina_rex_farwell_trial.jsonl`
- `kristina_rex_farwell_trial(1).jsonl`

## Group 12
- `Raw files for upload.zip::kristina_rex_recent.jsonl`
- `kristina_rex_recent(1).jsonl`

## Group 13
- `Raw files for upload.zip::michelemcphee_oct29.jsonl`
- `michelemcphee_oct29(1).jsonl`

## Group 14
- `Raw files for upload.zip::oct13_0945am_1pm.jsonl`
- `oct13_0945am_1pm.jsonl`

## Group 15
- `Raw files for upload.zip::oct13_1245pm_3pm.jsonl`
- `oct13_1245pm_3pm.jsonl`

## Group 16
- `Raw files for upload.zip::oct13_245pm_6pm.jsonl`
- `oct13_245pm_6pm.jsonl`

## Group 17
- `Raw files for upload.zip::oct26_05am_915am.jsonl`
- `oct26_05am_915am.jsonl`

## Group 18
- `Raw files for upload.zip::oct26_1145am_2pm.jsonl`
- `oct26_1145am_2pm.jsonl`

## Group 19
- `Raw files for upload.zip::oct26_130pm_4pm.jsonl`
- `oct26_130pm_4pm.jsonl`

## Group 20
- `Raw files for upload.zip::oct26_130pm_6pm.jsonl`
- `oct26_130pm_6pm.jsonl`

## Group 21
- `Raw files for upload.zip::oct26_330pm_6pm.jsonl`
- `oct26_330pm_6pm.jsonl`

## Group 22
- `Raw files for upload.zip::oct26_845am_1215pm.jsonl`
- `oct26_845am_1215pm.jsonl`

## Group 23
- `SupplementSources (2)(1).zip::SupplementSources/ameliarstern1_2026-10-20.jsonl`
- `SupplementSources.zip::ameliarstern1_2026-10-20.jsonl`

## Group 24
- `SupplementSources (2)(1).zip::SupplementSources/ameliarstern1_2026-10-28.jsonl`
- `SupplementSources.zip::ameliarstern1_2026-10-28.jsonl`

## Group 25
- `SupplementSources (2)(1).zip::SupplementSources/boozeybeauty_2026-10-20.jsonl`
- `SupplementSources.zip::boozeybeauty_2026-10-20.jsonl`

## Group 26
- `SupplementSources (2)(1).zip::SupplementSources/boozeybeauty_2026-10-28.jsonl`
- `SupplementSources.zip::boozeybeauty_2026-10-28.jsonl`

## Group 27
- `SupplementSources (2)(1).zip::SupplementSources/kristinarex_2026-10-20.jsonl`
- `SupplementSources.zip::kristinarex_2026-10-20.jsonl`

## Group 28
- `SupplementSources (2)(1).zip::SupplementSources/kristinarex_2026-10-28.jsonl`
- `SupplementSources.zip::kristinarex_2026-10-28.jsonl`

## Group 29
- `SupplementSources (2)(1).zip::SupplementSources/michelemcphee_2026-10-20.jsonl`
- `SupplementSources.zip::michelemcphee_2026-10-20.jsonl`

## Group 30
- `SupplementSources (2)(1).zip::SupplementSources/michelemcphee_2026-10-28.jsonl`
- `SupplementSources.zip::michelemcphee_2026-10-28.jsonl`

## Group 31
- `SupplementSources (2)(1).zip::SupplementSources/pennylikeacoin_2026-10-20.jsonl`
- `SupplementSources.zip::pennylikeacoin_2026-10-20.jsonl`

## Group 32
- `SupplementSources (2)(1).zip::SupplementSources/pennylikeacoin_2026-10-28.jsonl`
- `SupplementSources.zip::pennylikeacoin_2026-10-28.jsonl`

## Group 33
- `grant_today_FINAL_thread.jsonl`
- `grant_today_afternoon_thread(1).jsonl`
