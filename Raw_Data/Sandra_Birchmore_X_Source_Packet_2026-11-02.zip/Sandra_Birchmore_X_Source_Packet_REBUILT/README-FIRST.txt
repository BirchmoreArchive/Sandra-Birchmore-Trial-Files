SANDRA BIRCHMORE TRIAL — X SOURCE PACKET

FAST START
1. canonical_sources/GrantSmithEllis/ = strongest structurally validated day bundles where available.
2. canonical_raw/ = selected original extracted records for the broader corpus.
3. canonical_normalized/ = same corpus with reversible encoding repair only.
4. provenance/tweet_provenance.jsonl = audit trail back to every surviving extraction occurrence.
5. media/media_manifest.json = referenced media inventory; media recovery is a separate stage.
6. source_bundles/ = selected original source pulls for reproduction.

Historical X search is NOT assumed complete. Do not silently fill gaps or turn questions/commentary into testimony/findings.
See README.md and the per-day manifests for methodology and limitations.
