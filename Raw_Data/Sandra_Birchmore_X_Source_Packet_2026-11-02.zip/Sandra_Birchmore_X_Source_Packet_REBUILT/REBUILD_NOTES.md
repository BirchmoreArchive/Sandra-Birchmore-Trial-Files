# Rebuild Notes — November 2, 2026

This packet replaces the accidentally stripped baseline that contained only the late wrapper books.

## Why the counts differ from the earlier working-pack README

The earlier working README reported 118 JSONL file instances and 565 media objects. Those were counts from an earlier audit moment before later source drops and before the distributable-source selection was tightened.

This rebuild intentionally processes **selected surviving source bundles plus unique loose pulls** rather than counting byte-identical duplicate collections as separate archival inputs. It also incorporates later Oct. 13/14 and Oct. 30 source material that was not in the earlier media count. Consequently, the rebuild can have **fewer source instances but more unique tweet/media records**.

The historical duplicate inventory is preserved as `provenance/HISTORICAL_DUPLICATE_INVENTORY.md` so omitted exact duplicate collections remain auditable.

## What was not done

- The final November 2 v0.5.2 JSONL/CSV were not replaced with the superseded local 257-record v0.5.0 pair.
- Raw source text was not silently corrected.
- Missing posts were not inferred.
- Media referenced in JSON was indexed but not bulk-downloaded in this rebuild.

## Replacement status

`Sandra_Birchmore_X_Source_Packet_Baseline_2026-11-02.zip` is superseded and should not be used as the archival master.
